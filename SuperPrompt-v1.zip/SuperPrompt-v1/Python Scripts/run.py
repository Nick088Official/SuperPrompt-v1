import os
import subprocess

# Run pip install commands to install the required packages
subprocess.run(["pip", "install", "accelerate", "sentencepiece", "transformers", "torch"])
print("Successfully installed 'accelerate', 'sentencepiece', 'transformers', and 'torch' packages.")

from transformers import T5Tokenizer, T5ForConditionalGeneration
import torch

if torch.cuda.is_available():
    device = "cuda"
    print("Using GPU")
else:
    device = "cpu"
    print("Using CPU")

# Load the tokenizer and model
tokenizer = T5Tokenizer.from_pretrained("google/flan-t5-small")
model = T5ForConditionalGeneration.from_pretrained("roborovski/superprompt-v1", device_map="auto")

# Clearing the Screen
os.system('cls')

def main():
    # Get user input
    input_text = input("Enter the prompt you want to make better: ")

    # Get repetition penalty
    repetition_penalty = float(input("Repetition Penalty (the higher the less the AI repeats itself, 1.0 to 2.0): "))

    # Tokenize and convert to tensor
    input_ids = tokenizer(input_text, return_tensors="pt").input_ids.to(device)

    # Generate outputs
    outputs = model.generate(input_ids, max_new_tokens=250, repetition_penalty=repetition_penalty)

    # Decode and print the output
    dirty_text = tokenizer.decode(outputs[0])
    text = dirty_text.replace("<pad>", "").replace("</s>", "")
    print(f"Generated Better Prompt: {text}")

if __name__ == "__main__":
    while True:
        main()
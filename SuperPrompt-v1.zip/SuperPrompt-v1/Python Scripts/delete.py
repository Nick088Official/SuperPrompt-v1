# Create a Python script that uninstalls packages and unloads/deletes the model

import subprocess
import shutil

def uninstall_packages():
    try:
        # Run pip uninstall commands to remove the specified packages
        subprocess.run(["pip", "uninstall", "-y", "accelerate", "sentencepiece", "transformers", "torch"])
        print("Successfully uninstalled packages.")
    except Exception as e:
        print(f"Error uninstalling packages: {e}")

def unload_model():
    try:
        from transformers import T5Tokenizer, T5ForConditionalGeneration
        tokenizer = T5Tokenizer.from_pretrained("google/flan-t5-small")
        model = T5ForConditionalGeneration.from_pretrained("roborovski/superprompt-v1", device_map="auto")
        del model
        del tokenizer
        torch._C._cuda_emptyCache()
        print("Model unloaded successfully.")
    except Exception as e:
        print(f"Error unloading model: {e}")

if __name__ == "__main__":
    unload_model()
    uninstall_packages()

    print("Packages uninstalled and model unloaded/deleted successfully!")

import os
import subprocess
import random
import time

# Run pip install commands to install the required packages
subprocess.run(["pip", "install", "torch", "protobuf", "accelerate", "sentencepiece", "transformers"])
print("Successfully installed the packages.")

from transformers import T5Tokenizer, T5ForConditionalGeneration
import torch
import random

if torch.cuda.is_available():
    device = "cuda"
    print("Using GPU")
else:
    device = "cpu"
    print("Using CPU")

# Function to set precision
def set_precision(precision):
    if precision == "fp32":
        return torch.float32
    elif precision == "fp16":
        return torch.float16
    else:
        raise ValueError("Invalid precision. Please choose 'fp32' or 'fp16'.")

# Set precision
precision = input("Enter 'fp32' for FP32 precision which is higher and wider or 'fp16' for FP16 precision which is faster and less consuming memory: ")
precision_type = set_precision(precision)

# Load the tokenizer and model
tokenizer = T5Tokenizer.from_pretrained("google/flan-t5-small")
model = T5ForConditionalGeneration.from_pretrained("roborovski/superprompt-v1", device_map="auto", torch_dtype=precision_type)

model.to(device)

print(f"Loaded model succesfully in {precision} on {'GPU' if device == 'cuda' else 'CPU'}! Loading inference...")

time.sleep(3)

# Clearing the Screen
os.system('cls')

def main():
    # Get user input
    input_text = input("Enter the prompt you want to make better: ")

    # Get max new tokens
    max_new_tokens = float(input("Max New Tokens (maximum number of the tokens to generate, controls how long is the text, 250 to 512): "))

    # Get repetition penalty
    repetition_penalty = float(input("Repetition Penalty (the higher the less the AI repeats itself, 1.00 to 2.00): "))

    # Get Temperature
    temperature = float(input("Temperature (Higher values produce more diverse outputs, 0.00 to 1.00): "))

    # Get top_p
    top_p = float(input("Top_P (Higher values sample more low-probability tokens, 0.00 to 1.00): "))

    # Get top_k
    top_k = int(input("Top_K (Higher k means more diverse outputs by considering a range of tokens, 1 to 100): "))

    # Get seed
    seed = int(input("Seed (A starting point to initiate the generation process, any integers, put 0 for random): "))
    torch.manual_seed(seed)
    
    if seed == 0:
      seed = random.randint(1, 100000)
    else:
      seed = seed

    # Tokenize and convert to tensor
    input_ids = tokenizer(input_text, return_tensors="pt").input_ids.to(device)

    # Generate outputs
    outputs = model.generate(input_ids, max_new_tokens=max_new_tokens, repetition_penalty=repetition_penalty, do_sample=True, temperature=temperature, top_p=top_p, top_k=top_k)

    # Decode and print the output
    dirty_text = tokenizer.decode(outputs[0])
    text = dirty_text.replace("<pad>", "").replace("</s>", "")
    print(f"Generated Better Prompt: {text}")

if __name__ == "__main__":
    while True:
        main()
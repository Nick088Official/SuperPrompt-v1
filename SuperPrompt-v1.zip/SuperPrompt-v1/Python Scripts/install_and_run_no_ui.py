import os
import subprocess

# Run pip install commands to install the required packages
subprocess.run(["pip", "install", "torch", "protobuf", "accelerate", "sentencepiece", "transformers"])
print("Successfully installed 'accelerate', 'sentencepiece', 'transformers', and 'torch' packages.")

from transformers import T5Tokenizer, T5ForConditionalGeneration
import torch

if torch.cuda.is_available():
    device = "cuda"
    print("Using GPU")
else:
    device = "cpu"
    print("Using CPU")

# Now you can use 'device' for your PyTorch operations
torch.set_default_device(device)

# Load the tokenizer and model
tokenizer = T5Tokenizer.from_pretrained("google/flan-t5-small")
model = T5ForConditionalGeneration.from_pretrained("roborovski/superprompt-v1", device_map="auto")

# Clearing the Screen
os.system('cls')

def main():
    # Get user input
    input_text = input("Enter the prompt you want to make better: ")

    # Get max new tokens
    max_new_tokens = float(input("Max New Tokens (maximum number of the tokens to generate, controls how long is the text, 250 to 512): "))

    # Get repetition penalty
    repetition_penalty = float(input("Repetition Penalty (the higher the less the AI repeats itself, 1.00 to 2.00): "))

    # Get Temperature
    temperature = float(input("Temperature (Higher values produce more diverse outputs, 0.00 to 1.00): "))

    # Get top_p
    top_p = float(input("Top_P (Higher values sample more low-probability tokens, 0.00 to 1.00): "))

    # Get top_k
    top_k = int(input("Top_K (Higher k means more diverse outputs by considering a range of tokens, 1 to 100): "))

    # Tokenize and convert to tensor
    input_ids = tokenizer(input_text, return_tensors="pt").input_ids.to(device)

    # Generate outputs
    outputs = model.generate(input_ids, max_new_tokens=max_new_tokens, repetition_penalty=repetition_penalty, do_sample=True, temperature=temperature, top_p=top_p, top_k=top_k)

    # Decode and print the output
    dirty_text = tokenizer.decode(outputs[0])
    text = dirty_text.replace("<pad>", "").replace("</s>", "")
    print(f"Generated Better Prompt: {text}")

if __name__ == "__main__":
    while True:
        main()